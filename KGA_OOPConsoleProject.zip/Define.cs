﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KGA_OOPConsoleProject
{
    public static class Define
    {
        public const int ScreenWidth = 40;
        public const int ScreenHeight = 20;
        public const int pointPerSecond = 100;
    }
}
